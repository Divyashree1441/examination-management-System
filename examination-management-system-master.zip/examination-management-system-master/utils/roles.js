module.exports = {
     TEACHER : "teacher",
     STUDENT : "student",
     baseURL: "https://ems-in.herokuapp.com"
}
