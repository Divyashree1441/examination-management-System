export const Roles ={
    teacher: "teacher",
    student: "student"
}